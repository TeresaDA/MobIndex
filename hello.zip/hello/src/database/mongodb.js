const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://Teresa:t3r35a@mobindex-6rxsi.mongodb.net/test?retryWrites=true&w=majority";
const client = new MongoClient(uri, { useNewUrlParser: true });
client.connect(err => {
  const db = client.db("MobIndex");
  var cursor = db.collection("footnotes").find({});
  // perform actions on the collection object
  function iterateFunc(doc) {
    console.log(JSON.stringify(doc, null, 4));
 }
 
 function errorFunc(error) {
    console.log(error);
 }
 
 cursor.forEach(iterateFunc, errorFunc);
  
 client.close();
});
